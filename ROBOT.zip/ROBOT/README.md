<p align="center">
<img src="https://media.giphy.com/media/3oGRFAUNzSHAMWZLxe/giphy.gif" alt="GIF" width="128" height="128"/>
</p>

## Features

| 18+ |Yes|
| ------------- | ------------- |
| Nekopoi |❎|

| Creator |Yes|
| ------------- | ------------- |
| Respond img to sticker|✅|
| Respond img to sticker no bg|✅|
| Respond url to sticker|✅|
| Respond gif to sticker|✅|
| Respond giphy url to sticker|✅|
| Make a meme from photo|✅|
| Quotes maker result pict|✅|
| Nulis Bot|✅|

| Islam |Yes|
| ------------- | ------------- |
| List Surah|✅|
| Info Surah|✅|
| Surah|✅|
| Tafsir Alquran|✅|
| Alquran Audio/Voice|✅|
| Jadwal solat|✅|

| Downloader |Yes|
| ------------- | ------------- |
| Instagram |✅|
| Youtube Music |✅|
| Youtube Video |✅|

| Fun Group! |Yes|
| ------------- | ------------- |
| Simi-simi BOT|✅|
| Anti kata kasar|✅|

| Primbon |Yes|
| ------------- | ------------- |
| Arti nama |✅|
| Cek Jodoh |✅|

| Searchs |Yes|
| ------------- | ------------- |
| Images |✅|
| Subreddit |✅|
| Resep makanan |✅|
| Stalk IG |✅|
| Wikipedia |✅|
| Cuaca |✅|
| Chord musik |✅|
| Lirik musik |✅|
| Screen Crot!|✅|
| Play music|✅|
| whats anime?|✅|

| Random text |Yes|
| ------------- | ------------- |
| Pantun pakboy|✅|
| Fakta Menarik|✅|
| Kata Bijak|✅|
| Quotes|✅|

| Random image |Yes|
| ------------- | ------------- |
| Anime |✅|
| Kpop |✅|
| Memes |✅|


| Others |Yes|
| ------------- | ------------- |
| Teks to Sound/Voice|✅|
| Translate teks|✅|
| Get covid info from map|✅|
| Covid-19 Indo|✅|
| Shortlink|✅|
| Bap4k F0nt|✅|

| Groups |Yes|
| ------------- | ------------- |
| Admin||
| Add user|✅|
| Kick user|✅|
| Promote User|✅|
| Demote User|✅|
| Delete bot msg|✅|
| Tagall/mentions all|✅|
| Owner||
| Kick all members|✅|

| Owner bot |Yes|
| ------------- | ------------- |
| Broadcast|✅|
| Leave all group|✅|
| Delete all msgs|✅|
| Banned user|✅|



